# WerkHub – zwölf einzigartige Websites statt einem einheitlichen Baukasten

## Bereits bekannte Original-Websites (unverändert)

- FormatWerk: https://formatwerk.ablerain7.chatgpt.site/
- KI-Finder: https://ki-finder.ablerain7.chatgpt.site/

Diese Original-Websites werden direkt verlinkt; sie wurden nicht nachgebaut und bleiben mit ihrem vorhandenen Design und ihren Funktionen erhalten.

## Veröffentlichung (Aktualisierung des bestehenden WerkHub)

1. Netlify öffnen: https://app.netlify.com/
2. Das vorhandene Projekt `jazzy-kataifi-a4f915` aufrufen.
3. Unter **Deploys** dieses ZIP `WerkHub-12-Eigenstaendige-Websites-Netlify.zip` als manuellen Deploy verwenden (ZIP entpacken und Projektordner hochladen, wenn Netlify im Browser keinen ZIP-Upload akzeptiert).
4. Danach https://jazzy-kataifi-a4f915.netlify.app/ öffnen.

Das Veröffentlichen wurde hier **nicht** automatisch durchgeführt. Die vorhandene öffentliche Version bleibt unverändert, bis der neue Deploy erfolgt.

## Neue eigenständige URLs

Die zehn neuen Websites haben eigene Pfade auf derselben Netlify-Domain. Für eigenständige Domains können ihre Ordner später separat bei Netlify veröffentlicht und die Links im WerkHub angepasst werden:

- LernWerk: https://jazzy-kataifi-a4f915.netlify.app/lernwerk/
- DesignWerk: https://jazzy-kataifi-a4f915.netlify.app/designwerk/
- QRWerk: https://jazzy-kataifi-a4f915.netlify.app/qrwerk/
- FinanzWerk: https://jazzy-kataifi-a4f915.netlify.app/finanzwerk/
- KarriereWerk: https://jazzy-kataifi-a4f915.netlify.app/karrierewerk/
- BildWerk: https://jazzy-kataifi-a4f915.netlify.app/bildwerk/
- PlanWerk: https://jazzy-kataifi-a4f915.netlify.app/planwerk/
- RechenWerk: https://jazzy-kataifi-a4f915.netlify.app/rechenwerk/
- SpielWerk: https://jazzy-kataifi-a4f915.netlify.app/spielwerk/
- WebWerk: https://jazzy-kataifi-a4f915.netlify.app/webwerk/

## Projektstruktur

- `index.html`: WerkHub-Portalseite.
- `assets/links.js`: Zentrale URLs der Websites. Hier neue Domains eintragen, wenn du einzelne Websites selbst veröffentlichst.
- `assets/app.js` und `assets/style.css`: Nur Code/Design für die WerkHub-Portalseite.
- `lernwerk/`, `designwerk/`, ... `webwerk/`: Jeder Unterordner ist eine **eigenständig veröffentlichbare statische Website** mit ihrer eigenen `index.html`, eigenen Kopien von `app.js`, `style.css` und einer **individuellen** `identity.css`.
- `*/links.js`: Konfiguration des WerkHub-Links und der Navigation dieser einzelnen Website. Bei unabhängigen Domains die URLs hier ändern.

## Besonderheiten

- Kein einheitliches Zwangsdesign: Jede Website besitzt eigene Farben, Typografie, Hintergründe, Komponenten und Gestaltung.
- Nutzer öffnet über WerkHub einzelne URLs – bei FormatWerk/KI-Finder die vorhandenen Live-Websites und bei den zehn neuen Tools einzelne `/name/`-Adressen.
- Ein Link zum WerkHub und ein Website-Wechsler in allen **zehn neuen** Seiten; die ursprünglichen FormatWerk-/KI-Finder-Websites können ohne Originalquellcode nicht direkt um ein Menü ergänzt werden.
- Favoriten, Karteikarten, Budgetbuchungen usw. werden im lokalen Browserspeicher gehalten; zwischen eigenständigen Domains werden diese Daten nicht übertragen.
- Die Tools laufen statisch ohne einen eigenen Server. QRWerk nutzt eine eingebundene QR-Bibliothek (Lizenz im mitgelieferten Drittanbieterhinweis).
- Ein getrennter Deploy für eine einzelne Website ist möglich: Nur ihren Ordner mit dessen `index.html` als Hauptseite veröffentlichen. Der WerkHub-Kartenlink muss dann in `assets/links.js` aktualisiert werden. 
- Kein Ersatz für die bestehende FormatWerk-/KI-Finder-Quellcodesammlung. Bestehende Originale bleiben auf ihren Domains.
