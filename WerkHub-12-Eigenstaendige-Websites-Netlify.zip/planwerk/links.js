/* Hier Links aktualisieren, sobald einzelne Webprojekte eigene Domains haben. */
window.WERKHUB_DEFAULT_THEME="light";
window.WERKHUB_LINKS={
  "hub": "https://jazzy-kataifi-a4f915.netlify.app/",
  "formatwerk": "https://formatwerk.ablerain7.chatgpt.site/",
  "kitools": "https://ki-finder.ablerain7.chatgpt.site/",
  "lernwerk": "https://jazzy-kataifi-a4f915.netlify.app/lernwerk/",
  "designwerk": "https://jazzy-kataifi-a4f915.netlify.app/designwerk/",
  "qrwerk": "https://jazzy-kataifi-a4f915.netlify.app/qrwerk/",
  "finanzwerk": "https://jazzy-kataifi-a4f915.netlify.app/finanzwerk/",
  "karrierewerk": "https://jazzy-kataifi-a4f915.netlify.app/karrierewerk/",
  "bildwerk": "https://jazzy-kataifi-a4f915.netlify.app/bildwerk/",
  "planwerk": "./",
  "rechenwerk": "https://jazzy-kataifi-a4f915.netlify.app/rechenwerk/",
  "spielwerk": "https://jazzy-kataifi-a4f915.netlify.app/spielwerk/",
  "webwerk": "https://jazzy-kataifi-a4f915.netlify.app/webwerk/"
};
