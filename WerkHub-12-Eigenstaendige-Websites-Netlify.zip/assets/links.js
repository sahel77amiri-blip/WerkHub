/* Links hier ändern, wenn eine Website eine eigene Domain bekommt. */
window.WERKHUB_LINKS={
  "hub": "./",
  "formatwerk": "https://formatwerk.ablerain7.chatgpt.site/",
  "kitools": "https://ki-finder.ablerain7.chatgpt.site/",
  "lernwerk": "lernwerk/",
  "designwerk": "designwerk/",
  "qrwerk": "qrwerk/",
  "finanzwerk": "finanzwerk/",
  "karrierewerk": "karrierewerk/",
  "bildwerk": "bildwerk/",
  "planwerk": "planwerk/",
  "rechenwerk": "rechenwerk/",
  "spielwerk": "spielwerk/",
  "webwerk": "webwerk/"
};
