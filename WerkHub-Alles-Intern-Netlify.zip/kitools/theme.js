/* Das vorhandene Farbschema vor dem ersten Zeichnen wiederherstellen. */
(function () {
  'use strict';
  try {
    document.documentElement.dataset.theme = localStorage.getItem('ki-finder-theme') === 'light' ? 'light' : 'dark';
  } catch {
    document.documentElement.dataset.theme = 'dark';
  }
})();

