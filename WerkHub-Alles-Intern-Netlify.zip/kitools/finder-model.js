/* KI-Finder: Aufgaben, Filter und gespeicherte Auswahl. */
(function () {
  'use strict';
  const tasks=[
      {id:'all',label:'✳ Alle Tools'}, {id:'hausarbeit',label:'Hausarbeit & Studium'}, {id:'research',label:'Recherche & Quellen'},
      {id:'writing',label:'Texte schreiben'}, {id:'editing',label:'Texte verbessern'}, {id:'translate',label:'Übersetzen'},
      {id:'documents',label:'PDFs & Notizen'}, {id:'present',label:'Präsentationen'}, {id:'images',label:'Bilder erstellen'},
      {id:'video',label:'Video erstellen'}, {id:'audio',label:'Audio & Stimme'}, {id:'music',label:'Musik erstellen'},
      {id:'meetings',label:'Meetings'}, {id:'code',label:'Programmieren'}, {id:'learn',label:'Lernen'}
    ];
    const taskTools={
      all:null,
      hausarbeit:['notebooklm','elicit','consensus','scispace','semanticscholar','scite','chatgpt','claude','perplexity','gemini','grammarly'],
      research:['perplexity','notebooklm','elicit','consensus','scispace','semanticscholar','scite','gemini','chatgpt','claude'],
      writing:['chatgpt','claude','gemini','grammarly','deepl','gamma'],
      editing:['grammarly','deepl','chatgpt','claude','gemini'],
      translate:['deepl','chatgpt','claude','gemini'],
      documents:['notebooklm','chatgpt','claude','gemini','scispace','elicit'],
      present:['gamma','canva','chatgpt','claude','perplexity'],
      images:['firefly','leonardo','chatgpt','canva'],
      video:['runway','canva','firefly'],
      audio:['elevenlabs','otter','fathom'],
      music:['suno','elevenlabs'],
      meetings:['otter','fathom'],
      code:['githubcopilot','replit','lovable','chatgpt','claude','gemini'],
      learn:['chatgpt','claude','gemini','notebooklm','consensus','elicit','scispace','semanticscholar','perplexity']
    };

  function matchesPrice(tool, filter) {
    if (filter === 'free') return tool.free;
    if (filter === 'paid') return tool.price !== null || (Boolean(tool.paid) && !/(kein abo|kostenlos)/i.test(tool.paid));
    if (filter === 'under10') return tool.price !== null && tool.price <= 10;
    if (filter === 'under20') return tool.price !== null && tool.price <= 20;
    return true;
  }

  function filterTools(tools, options = {}) {
    const selected = Array.from(options.tasks || []);
    const saved = options.saved || new Set();
    const list = tools.filter(tool =>
      selected.every(task => taskTools[task]?.includes(tool.id)) &&
      matchesPrice(tool, options.price || 'all') &&
      (!options.onlySaved || saved.has(tool.id))
    );
    if (options.sort === 'cheap') list.sort((a, b) => (a.price ?? 999) - (b.price ?? 999));
    else if (options.sort === 'expensive') list.sort((a, b) => (b.price ?? -1) - (a.price ?? -1));
    else if (options.sort === 'az') list.sort((a, b) => a.name.localeCompare(b.name, 'de'));
    else if (selected.length) {
      const score = tool => selected.reduce((sum, task) => {
        const pool = taskTools[task];
        return sum + pool.indexOf(tool.id) / pool.length;
      }, 0);
      list.sort((a, b) => score(a) - score(b));
    }
    return list;
  }

  function readSaved(storage, tools) {
    try {
      const values = JSON.parse(storage.getItem('ki-finder-saved') || '[]');
      const known = new Set(tools.map(tool => tool.id));
      return new Set(Array.isArray(values) ? values.filter(id => known.has(id)) : []);
    } catch {
      return new Set();
    }
  }

  window.KIFinder = Object.freeze({tasks, taskTools, filterTools, readSaved});
})();

