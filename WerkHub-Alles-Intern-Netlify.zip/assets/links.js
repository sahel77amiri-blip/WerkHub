/* Gemeinsame interne WerkHub-Adressen für alle zwölf Werkzeuge. */
window.WERKHUB_LINKS=Object.freeze({
  "hub": "/",
  "formatwerk": "/formatwerk/",
  "kitools": "/kitools/",
  "lernwerk": "/lernwerk/",
  "designwerk": "/designwerk/",
  "qrwerk": "/qrwerk/",
  "finanzwerk": "/finanzwerk/",
  "karrierewerk": "/karrierewerk/",
  "bildwerk": "/bildwerk/",
  "planwerk": "/planwerk/",
  "rechenwerk": "/rechenwerk/",
  "spielwerk": "/spielwerk/",
  "webwerk": "/webwerk/"
});
