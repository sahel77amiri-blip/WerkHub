/* Individuelles Startdesign; Adressen kommen aus assets/links.js. */
window.WERKHUB_DEFAULT_THEME="light";
