# WerkHub – alle zwölf Werkzeuge unter derselben Adresse

Dieses Paket aktualisiert das bestehende WerkHub-Projekt. KI-FinderWerk und
FormatWerk sind jetzt vollständig enthalten und werden als interne Unterseiten
geöffnet. Startseite, Website-Auswahl und Home-Schaltflächen führen innerhalb
derselben WerkHub-Domain zu allen zwölf Werkzeugen.

## Veröffentlichung im bestehenden Netlify-Projekt

1. Diese ZIP-Datei entpacken.
2. Bei Netlify das bestehende Projekt `jazzy-kataifi-a4f915` öffnen.
3. Auf der Seite **Deploys** den entpackten Projektordner als aktualisierten
   manuellen Deploy hochladen. Der richtige Ordner enthält direkt `index.html`,
   `assets`, `formatwerk`, `kitools` und die zehn weiteren Werkzeugordner.
4. Nach dem erfolgreichen Deploy die bisherige Adresse öffnen:
   https://jazzy-kataifi-a4f915.netlify.app/

Die Projektadresse bleibt erhalten, wenn der Upload als neuer Deploy im
bestehenden Netlify-Projekt erfolgt. Das Herunterladen oder Entpacken dieser
Datei allein ändert die veröffentlichte Website noch nicht.

Es gibt keinen Build-Schritt und keine zusätzlich zu installierenden Pakete.
Die mitgelieferte Netlify-Konfiguration verwendet den Projektordner direkt als
öffentlichen Ordner.

## Ansicht wie auf Foto 2

Alle Links zwischen den zwölf Werkzeugen und der Startseite bleiben innerhalb
der WerkHub-Adresse und öffnen im vorhandenen Fenster.

Für die Nutzung ohne zusätzliche Browser-Adressleiste WerkHub über sein
Home-Bildschirm-Symbol als Web-App starten. Bei einer neuen Einrichtung in
Safari: Teilen → Zu Home-Bildschirm hinzufügen → Als Web-App öffnen aktivieren.
Das gemeinsame Web-App-Manifest umfasst die gesamte Website einschließlich aller
zwölf Unterseiten.

In einem normalen Safari-Tab gehört die Adressleiste zur Browseroberfläche.
Externe Anbieterlinks im KI-Katalog führen weiterhin zu den jeweiligen Anbietern.

## Enthaltene Werkzeuge

| Werkzeug | Interner Pfad |
| --- | --- |
| FormatWerk | /formatwerk/ |
| KI-FinderWerk | /kitools/ |
| LernWerk | /lernwerk/ |
| DesignWerk | /designwerk/ |
| QRWerk | /qrwerk/ |
| FinanzWerk | /finanzwerk/ |
| KarriereWerk | /karrierewerk/ |
| BildWerk | /bildwerk/ |
| PlanWerk | /planwerk/ |
| RechenWerk | /rechenwerk/ |
| SpielWerk | /spielwerk/ |
| WebWerk | /webwerk/ |

## Erhaltene Funktionen und Gestaltung

- KI-FinderWerk: 24 Tools mit Beschreibungen, Gratisumfang, bisherigen Preisen,
  Abo-Inhalt, Vor- und Nachteilen; kombinierbare Aufgaben mit UND-Verknüpfung,
  Preisfilter, Sortierung, Merkliste mit Nur-Gemerkte-Filter und Vergleich von bis
  zu drei Tools. Preisstand der übernommenen Daten: 20. Oktober 2026.
- FormatWerk: die bisherigen Datei-Konverter, PDF-/Office-Funktionen,
  Mehrfachauswahl, Optionen und Downloads.
- Die zehn weiteren Werkzeuge behalten ihre Funktionen und individuellen Designs.
- Hell-/Dunkelmodus, WerkHub-Favoriten und die vorhandenen Speicher-Schlüssel
  bleiben erhalten.

Vorhandene Daten auf derselben WerkHub-Domain bleiben im Browserspeicher.
Die frühere KI-Finder-Merkliste auf der separaten ChatGPT-Sites-Domain wird
durch den Domainwechsel nicht automatisch in WerkHub übertragen.

## Weiterentwicklung

Jeder Werkzeugordner bleibt ein eigener Bereich mit seinen Dateien. Weitere
Funktionen können jeweils dort ergänzt werden.

Die Adressen werden zentral in `assets/links.js` gepflegt. Alle Seiten verwenden
diese gemeinsame Zuordnung. Änderungen an den internen Werkzeugen werden über
dieses WerkHub-Projekt auf Netlify veröffentlicht. Eine Änderung ausschließlich
an einer früheren eigenständigen ChatGPT Site aktualisiert diese internen
Kopien nicht automatisch.

## Prüfung

JavaScript, lokale Dateiverweise, interne Navigation und das Web-App-Manifest
sind geprüft. Die Funktionen und Designs der zehn vorhandenen Werkzeuge sowie
die übernommenen Dateien von FormatWerk und KI-FinderWerk wurden mit ihren
Ausgangsständen verglichen. Alle automatisierten Prüfungen bestehen.

Eine visuelle Browserprüfung ist in dieser Umgebung derzeit nicht möglich,
weil der Vorschau-Dienst nicht verfügbar ist. Die Darstellung auf einem echten
iPhone muss nach dem Netlify-Deploy geprüft werden.

## Quellen für Veröffentlichung und Web-App-Nutzung

- Netlify: https://docs.netlify.com/deploy/create-deploys/
- Apple: https://support.apple.com/de-de/guide/iphone/iphea86e5236/ios
- Web-App-Bereich: https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Manifest/Reference/scope
