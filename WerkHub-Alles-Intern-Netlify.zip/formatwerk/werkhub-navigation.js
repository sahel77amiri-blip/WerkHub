/* WerkHub Navigation: eigenständige Seiten teilen dieselbe Website-Auswahl. */
(function () {
  'use strict';
  const LINKS = window.WERKHUB_LINKS || {};
  const ROOT = LINKS.hub || '/';
  const APPS = [
    ['formatwerk','FormatWerk','file','#70a8ff',ROOT+'formatwerk/'],
    ['kitools','KI-FinderWerk','spark','#bd8eff',ROOT+'kitools/'],
    ['lernwerk','LernWerk','book','#a79aff',ROOT+'lernwerk/'],
    ['designwerk','DesignWerk','spark','#f19ac2',ROOT+'designwerk/'],
    ['qrwerk','QRWerk','qrcode','#63d8c3',ROOT+'qrwerk/'],
    ['finanzwerk','FinanzWerk','money','#e5bc70',ROOT+'finanzwerk/'],
    ['karrierewerk','KarriereWerk','briefcase','#7da6ff',ROOT+'karrierewerk/'],
    ['bildwerk','BildWerk','image','#ee9d86',ROOT+'bildwerk/'],
    ['planwerk','PlanWerk','calendar','#c9a0ff',ROOT+'planwerk/'],
    ['rechenwerk','RechenWerk','calc','#88d9e9',ROOT+'rechenwerk/'],
    ['spielwerk','SpielWerk','game','#ffa97c',ROOT+'spielwerk/'],
    ['webwerk','WebWerk','code','#74dfb8',ROOT+'webwerk/']
  ];
  function appHref(app) {return LINKS[app[0]] || app[4];}
  const icons = {
    grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
    home:'<path d="m3 11 9-8 9 8"/><path d="M5 10v11h14V10M9 21v-7h6v7"/>',
    file:'<path d="M6 2h9l5 5v15H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z"/><path d="M14 2v6h6M9 13h7m-7 4h7"/>',
    spark:'<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7Z"/><path d="m19 17 .8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8Z"/>',
    book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>',
    qrcode:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="5" y="5" width="3" height="3"/><rect x="16" y="5" width="3" height="3"/><path d="M14 14h2v2h-2zm5 0h2v2h-2zm-5 5h2v2h-2zm3-2h2v4"/>',
    money:'<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M6 4h12"/>',
    briefcase:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13c6 3 12 3 18 0"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 2v6M17 2v6M3 10h18"/>',
    calc:'<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h2m4 0h2m-8 5h2m4 0h2"/>',
    game:'<path d="M6 8h12a4 4 0 0 1 4 4l-1 6a3 3 0 0 1-5 2l-3-3h-2l-3 3a3 3 0 0 1-5-2l-1-6a4 4 0 0 1 4-4Z"/><path d="M7 11v6m-3-3h6m7-2h.01m2 3h.01"/>',
    code:'<path d="m8 6-6 6 6 6m8-12 6 6-6 6m-3-14-2 20"/>'
  };
  function svg(name) {return '<svg viewBox="0 0 24 24" aria-hidden="true">'+(icons[name]||icons.grid)+'</svg>';}
  function init() {
    const button = document.querySelector('[data-wh-switch]');
    if (!button) return;
    const current = button.getAttribute('data-wh-switch');
    const home = document.querySelector('.wh-header__home');
    if (home) home.href = ROOT;
    const popup = document.createElement('div');
    popup.className='wh-popup'; popup.id='wh-switch-popup'; popup.hidden=true;
    popup.setAttribute('role','region'); popup.setAttribute('aria-label','Website-Auswahl');
    popup.innerHTML = '<div class="wh-popup__top"><div><div class="wh-popup__heading">Zu einer Website wechseln</div><span class="wh-popup__sub">12 Werkzeuge im WerkHub</span></div><button type="button" class="wh-popup__close" aria-label="Menü schließen">×</button></div>'+
      '<a class="wh-popup__hub" target="_self" href="'+ROOT+'">'+svg('home')+'<span>WerkHub <small>Alle zwölf Websites im Überblick</small></span>↗</a>'+
      '<nav class="wh-popup__grid" aria-label="Alle Websites">'+APPS.map(function(app){return '<a class="wh-popup__link" target="_self" href="'+appHref(app)+'"'+(app[0]===current?' aria-current="page"':'')+'><span class="wh-popup__icon" style="--wh-icon:'+app[3]+'">'+svg(app[2])+'</span><span>'+app[1]+'</span></a>';}).join('')+'</nav>'+
      '<p class="wh-popup__footer">Jede Website hat ihr eigenes Design.</p>';
    document.body.appendChild(popup);
    button.setAttribute('aria-controls','wh-switch-popup');button.setAttribute('aria-expanded','false');button.setAttribute('aria-haspopup','true');
    function setOpen(open, returnFocus) {
      popup.hidden=!open;button.setAttribute('aria-expanded',String(open));
      if(open) {position();}else if(returnFocus){button.focus();}
    }
    function position() {
      const box=button.getBoundingClientRect();
      const top=Math.min(Math.max(8,box.bottom+8),Math.max(8,window.innerHeight-140));
      const availableRight=Math.max(12, window.innerWidth - Math.min(480, window.innerWidth - 24) - 12);
      const right=Math.min(availableRight,Math.max(12,window.innerWidth-box.right));
      popup.style.setProperty('--wh-popup-top',top+'px');
      popup.style.setProperty('--wh-popup-right',right+'px');
    }
    button.addEventListener('click',function(){setOpen(popup.hidden);});
    popup.querySelector('.wh-popup__close').addEventListener('click',function(){setOpen(false,true);});
    document.addEventListener('pointerdown',function(e){if(!popup.hidden&&!popup.contains(e.target)&&!button.contains(e.target))setOpen(false);});
    document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!popup.hidden){e.stopPropagation();setOpen(false,true);}});
    window.addEventListener('resize',function(){if(!popup.hidden)position();});
    window.addEventListener('scroll',function(){if(!popup.hidden)position();},true);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
